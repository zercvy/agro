import { Request, Response } from 'express'
import db from '../models/db'

export const getAllCultures = async (req: Request, res: Response) => {
  try {
    const [rows] = await db.execute('SELECT * FROM cultures')
    res.json(rows)
  } catch (err) {
    console.error('Ошибка при получении всех культур:', err)
    res.status(500).json({ error: 'Ошибка при получении культур' })
  }
}

export const getCultureTree = async (req: Request, res: Response) => {
  try {
    const [rows] = await db.execute<({ id: number, name: string, parent_id: number | null })[]>(
      'SELECT id, name, parent_id FROM cultures'
    )
    const flat = rows as any[]

    // построение дерева
    const map = new Map<number, any>()
    const tree: any[] = []

    flat.forEach(item => {
      map.set(item.id, { id: item.id, name: item.name, children: [] })
    })
    flat.forEach(item => {
      const node = map.get(item.id)
      if (item.parent_id && map.has(item.parent_id)) {
        map.get(item.parent_id).children.push(node)
      } else {
        tree.push(node)
      }
    })

    res.json(tree)
  } catch (err) {
    console.error('Ошибка при получении иерархии культур:', err)
    res.status(500).json({ error: 'Ошибка при получении иерархии культур' })
  }
}
